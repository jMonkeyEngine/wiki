/*
 * Copyright (c) 2003-2008 jMonkeyEngine
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are
 * met:
 *
 * * Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 *
 * * Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in the
 *   documentation and/or other materials provided with the distribution.
 *
 * * Neither the name of 'jMonkeyEngine' nor the names of its contributors 
 *   may be used to endorse or promote products derived from this software 
 *   without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
 
package jmetest.flagrushtut.lesson10;
 
 
import jmetest.effects.RenParticleEditor;
import jmetest.flagrushtut.lesson10.Vehicle;
 
import com.jme.bounding.BoundingBox;
import com.jme.image.Texture;
import com.jme.math.FastMath;
import com.jme.math.Vector3f;
import com.jme.renderer.ColorRGBA;
import com.jme.scene.Controller;
import com.jme.scene.Node;
import com.jme.scene.Spatial;
import com.jme.scene.state.BlendState;
import com.jme.scene.state.RenderState;
import com.jme.scene.state.TextureState;
import com.jme.system.DisplaySystem;
import com.jme.util.TextureManager;
import com.jmex.effects.particles.ParticleSystem;
import com.jmex.effects.particles.ParticleFactory;
import com.jmex.effects.particles.SimpleParticleInfluenceFactory;
 
import java.util.logging.Logger;
 
 
public class CollisionDetection{
	private static final Logger logger = Logger.getLogger(Lesson10.class
            .getName());
 
    public static final int BounceOff = 0;
    public static final int Stop = 1;
 
	private Vehicle player;
	private Node target;
	private int NextMove;
	private ParticleSystem particleGeom;
	private float Zextent;
 
	public CollisionDetection(Vehicle Player, Node Target,int NextMove) {
        this.player = Player;
        this.target = Target;
        this.NextMove = NextMove;
        this.Zextent =((BoundingBox)player.getWorldBound()).zExtent;
        createParticles();
    }
	public CollisionDetection(Vehicle Player, Spatial Target,int NextMove) {
        this.player = Player;
        this.target = (Node)Target;
        this.NextMove = NextMove;
        this.Zextent =((BoundingBox)player.getWorldBound()).zExtent;
        createParticles();
    }
 
    public void ProcessCollisions() {
    	if (NextMove == BounceOff){
               if (player.hasCollision(target, false)){
        		if (player.frontwheel.hasCollision(target, false)){
        			player.setVelocity(-Math.abs(player.getVelocity()));
        			if (player.getVelocity() > -0.5)
        				player.setVelocity(-0.5f);
            		        particleGeom.setLocalTranslation(0F,player.frontwheel.getLocalTranslation().y*0.0025f, Zextent);
        			particleGeom.forceRespawn();
        		} else if(player.backwheel.hasCollision(target, false)){
        			player.setVelocity(Math.abs(player.getVelocity()));
        			if (player.getVelocity() < 0.5)
        				player.setVelocity(0.5f);
            		        particleGeom.setLocalTranslation(0F,player.backwheel.getLocalTranslation().y*0.0025f, -Zextent);
        			particleGeom.forceRespawn();
        		}
        	}
    	}else if (NextMove == Stop){
               if (player.hasCollision(target, false)){
        		if (player.frontwheel.hasCollision(target, false)){
                                player.setMaxSpeed(0f);
                                player.setMinSpeed(15f);
        		} else if(player.backwheel.hasCollision(target, false)){
                                player.setMaxSpeed(25f);
                                player.setMinSpeed(0f);
        		} else {
                                player.setMaxSpeed(25f);
                                player.setMinSpeed(15f);
                        }
        	}
    	}
    }
 
 
    private void createParticles(){
		particleGeom = ParticleFactory.buildParticles("collsion", 300);
    	particleGeom.addInfluence(SimpleParticleInfluenceFactory
    			.createBasicGravity(new Vector3f(0, -0.01f, 0), true));
    	particleGeom.setEmissionDirection(new Vector3f(0.0f, 1.0f, 0.0f));
    	particleGeom.setMaximumAngle(360f * FastMath.DEG_TO_RAD);
    	particleGeom.setMinimumLifeTime(2000.0f);
    	particleGeom.setMaximumLifeTime(4000.0f);
    	particleGeom.setInitialVelocity(.004f);
    	particleGeom.recreate(FastMath.nextRandomInt(6, 20));
    	particleGeom.setStartSize(.05f);
    	particleGeom.setEndSize(.02f);
    	particleGeom.setStartColor(new ColorRGBA(1.0f, 0.796875f, 0.1992f, 1.0f));
    	particleGeom.setEndColor(new ColorRGBA(1.0f, 1.0f, 0.5976f, 1.0f));
    	//particleGeom.warmUp(120);
    	particleGeom.getParticleController().setRepeatType(Controller.RT_CLAMP);
 
    	BlendState as = (BlendState) particleGeom
    		.getRenderState(RenderState.RS_BLEND);
    	if (as == null) {
        	as = DisplaySystem.getDisplaySystem().getRenderer()
        		.createBlendState();
        	as.setBlendEnabled(true);
        	as.setSourceFunction(BlendState.SourceFunction.SourceAlpha);
        	as.setTestEnabled(true);
        	as.setTestFunction(BlendState.TestFunction.GreaterThan);
        	particleGeom.setRenderState(as);
        	particleGeom.updateRenderState();
    	}
    	as.setDestinationFunction(BlendState.DestinationFunction.One);
    	TextureState ts = DisplaySystem.getDisplaySystem().getRenderer().createTextureState();
    	ts.setTexture(TextureManager.loadTexture(RenParticleEditor.class
            	.getClassLoader().getResource(
                    	"jmetest/data/texture/flaresmall.jpg"),
                    Texture.MinificationFilter.BilinearNearestMipMap, Texture.MagnificationFilter.Bilinear));
    	particleGeom.setRenderState(ts);
 
    	player.attachChild(particleGeom);
    	particleGeom.updateRenderState();
    }
}


