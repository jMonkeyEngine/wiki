#!/bin/bash
if [ -n "$1" ] 
then
JMEPATH=$1
echo "OK, using jME installation in path $JMEPATH"
rm -vf jmetest/flagrushtut/lesson10/*.class
rm -vf jmetest/flagrushtut/lesson10/actions/*.class
javac -cp ".:$JMEPATH/jME_2.0.jar" jmetest/flagrushtut/lesson10/*.java
java -cp ".:$JMEPATH/jME_2.0.jar" -Djava.library.path="$JMEPATH/lib/natives/" jmetest/flagrushtut/lesson10/Lesson10
else
echo -e "Usage:\n $0 \"/your/path/to/jME_2.0_Complete/\""
fi
