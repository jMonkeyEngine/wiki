/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package arm;

import com.jmex.physics.CollisionGroup;
import com.jmex.physics.PhysicsSpace;
import com.jmex.physics.StaticPhysicsNode;
import java.util.HashMap;

/**
 * The RoboterCollisionController creates rules which collisions,
 * between the servos of the robot and the floor,
 * should be ignored and which not from the physic engine.
 *
 * @author night
 */
public class RoboterCollisionController {

    private PhysicsSpace physicsSpace;
    StaticPhysicsNode floor;
    private HashMap<String, Servo> servoHashMap;
    private HashMap<String,CollisionGroup> collisionGroups = new HashMap<String,CollisionGroup>();

    public RoboterCollisionController(PhysicsSpace physicsSpace, StaticPhysicsNode floor) {

        this.physicsSpace = physicsSpace;
        this.floor = floor;

        CollisionGroup floorGroup = physicsSpace.createCollisionGroup("Floor");

        CollisionGroup kopfGroup = physicsSpace.createCollisionGroup("Kopf");

        CollisionGroup brustGroup = physicsSpace.createCollisionGroup("Brust");

        CollisionGroup rOberarmGroup = physicsSpace.createCollisionGroup("rOberarm");
        CollisionGroup rUnterarmGroup = physicsSpace.createCollisionGroup("rUnterarm");
        CollisionGroup rHandGroup = physicsSpace.createCollisionGroup("rHand");

        CollisionGroup lOberarmGroup = physicsSpace.createCollisionGroup("lOberarm");
        CollisionGroup lUnterarmGroup = physicsSpace.createCollisionGroup("lUnterarm");
        CollisionGroup lHandGroup = physicsSpace.createCollisionGroup("lHand");

        CollisionGroup rHuefteGroup = physicsSpace.createCollisionGroup("rHuefte");
        CollisionGroup rOberSchenkelServoGroup = physicsSpace.createCollisionGroup("rOberschenkelServo");
        CollisionGroup rOberSchenkelGroup = physicsSpace.createCollisionGroup("rOberschenkel");
        CollisionGroup rUnterSchenkelGroup = physicsSpace.createCollisionGroup("rUnterschenkel");
        CollisionGroup rFussServoGroup = physicsSpace.createCollisionGroup("rFussServo");
        CollisionGroup rFussGroup = physicsSpace.createCollisionGroup("rFuss");

        CollisionGroup lHuefteGroup = physicsSpace.createCollisionGroup("lHuefte");
        CollisionGroup lOberSchenkelServoGroup = physicsSpace.createCollisionGroup("lOberschenkelServo");
        CollisionGroup lOberSchenkelGroup = physicsSpace.createCollisionGroup("lOberschenkel");
        CollisionGroup lUnterSchenkelGroup = physicsSpace.createCollisionGroup("lUnterschenkel");
        CollisionGroup lFussServoGroup = physicsSpace.createCollisionGroup("lFussServo");
        CollisionGroup lFussGroup = physicsSpace.createCollisionGroup("lFuss");

        collisionGroups.put(floorGroup.getName(), floorGroup);

        floor.setCollisionGroup(floorGroup);

        collisionGroups.put(kopfGroup.getName(), kopfGroup);

        collisionGroups.put(brustGroup.getName(), brustGroup);

        collisionGroups.put(rOberarmGroup.getName(),    rOberarmGroup);
        collisionGroups.put(rUnterarmGroup.getName(),   rUnterarmGroup);
        collisionGroups.put(rHandGroup.getName(),       rHandGroup);

        collisionGroups.put(lOberarmGroup.getName(),    lOberarmGroup);
        collisionGroups.put(lUnterarmGroup.getName(),   lUnterarmGroup);
        collisionGroups.put(lHandGroup.getName(),       lHandGroup);

        collisionGroups.put(rHuefteGroup.getName(),         rHuefteGroup);
        collisionGroups.put(rOberSchenkelServoGroup.getName(), rOberSchenkelServoGroup);
        collisionGroups.put(rOberSchenkelGroup.getName(),   rOberSchenkelGroup);
        collisionGroups.put(rUnterSchenkelGroup.getName(),  rUnterSchenkelGroup);
        collisionGroups.put(rFussServoGroup.getName(),      rFussServoGroup);
        collisionGroups.put(rFussGroup.getName(),           rFussGroup);

        collisionGroups.put(lHuefteGroup.getName(),         lHuefteGroup);
        collisionGroups.put(lOberSchenkelServoGroup.getName(), lOberSchenkelServoGroup);
        collisionGroups.put(lOberSchenkelGroup.getName(),   lOberSchenkelGroup);
        collisionGroups.put(lUnterSchenkelGroup.getName(),  lUnterSchenkelGroup);
        collisionGroups.put(lFussServoGroup.getName(),      lFussServoGroup);
        collisionGroups.put(lFussGroup.getName(),           lFussGroup);

        for (CollisionGroup group : collisionGroups.values()) {

            for (CollisionGroup group2 : collisionGroups.values()) {

            group.collidesWith(group2, true);
            }
        }

        

        kopfGroup.collidesWith(brustGroup, false);

        brustGroup.collidesWith(kopfGroup, false);
        brustGroup.collidesWith(rOberarmGroup, false);
        brustGroup.collidesWith(lOberarmGroup, false);
        brustGroup.collidesWith(rHuefteGroup, false);
        brustGroup.collidesWith(lHuefteGroup, false);

        //---------------------------------

        rOberarmGroup.collidesWith(brustGroup, false);
        rOberarmGroup.collidesWith(rUnterarmGroup, false);

        rUnterarmGroup.collidesWith(rOberarmGroup, false);
        rUnterarmGroup.collidesWith(rHandGroup, false);

        rHandGroup.collidesWith(rUnterarmGroup, false);

        //---------------------------------

        lOberarmGroup.collidesWith(brustGroup, false);
        lOberarmGroup.collidesWith(lUnterarmGroup, false);

        lUnterarmGroup.collidesWith(lOberarmGroup, false);
        lUnterarmGroup.collidesWith(lHandGroup, false);

        lHandGroup.collidesWith(lUnterarmGroup, false);

        //---------------------------------

        lHuefteGroup.collidesWith(brustGroup, false);
        lHuefteGroup.collidesWith(lOberSchenkelServoGroup, false);

        lOberSchenkelServoGroup.collidesWith(lHuefteGroup, false);
        lOberSchenkelServoGroup.collidesWith(lOberSchenkelGroup, false);

        lOberSchenkelGroup.collidesWith(lOberSchenkelServoGroup, false);
        lOberSchenkelGroup.collidesWith(lUnterSchenkelGroup, false);

        lUnterSchenkelGroup.collidesWith(lOberSchenkelGroup, false);
        lUnterSchenkelGroup.collidesWith(lFussServoGroup, false);

        lFussServoGroup.collidesWith(lUnterSchenkelGroup, false);
        lFussServoGroup.collidesWith(lFussGroup, false);

        lFussGroup.collidesWith(lFussServoGroup, false);

        //---------------------------------


        rHuefteGroup.collidesWith(brustGroup, false);
        rHuefteGroup.collidesWith(rOberSchenkelServoGroup, false);

        rOberSchenkelServoGroup.collidesWith(rHuefteGroup, false);
        rOberSchenkelServoGroup.collidesWith(rOberSchenkelGroup, false);

        rOberSchenkelGroup.collidesWith(rOberSchenkelServoGroup, false);
        rOberSchenkelGroup.collidesWith(rUnterSchenkelGroup, false);

        rUnterSchenkelGroup.collidesWith(rOberSchenkelGroup, false);
        rUnterSchenkelGroup.collidesWith(rFussServoGroup, false);

        rFussServoGroup.collidesWith(rUnterSchenkelGroup, false);
        rFussServoGroup.collidesWith(rFussGroup, false);

        rFussGroup.collidesWith(rFussServoGroup, false);
    }

    /**
     * @return the physicsSpace
     */
    public PhysicsSpace getPhysicsSpace() {
        return physicsSpace;
    }

    /**
     * @return the servoHashMap
     */
    public HashMap<String, Servo> getServoHashMap() {
        return servoHashMap;
    }

    /**
     * @param servoHashMap the servoHashMap to set
     */
    public void setServoHashMap(HashMap<String, Servo> servoHashMap) {
        this.servoHashMap = servoHashMap;
    }

    /**
     * @return the collisionGroups
     */
    public HashMap<String, CollisionGroup> getCollisionGroups() {
        return collisionGroups;
    }


}

