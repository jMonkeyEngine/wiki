/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package arm;

import com.jme.math.FastMath;
import com.jme.math.Vector3f;
import com.jme.scene.Spatial;
import com.jmex.physics.DynamicPhysicsNode;
import com.jmex.physics.Joint;
import com.jmex.physics.JointAxis;
import com.jmex.physics.impl.jbullet.joints.JBulletJoint;

/**
 *
 * The Class simulates a servo, which is needed to move the parts of the robot.
 *  *
 * @author night
 */
public class Servo {

    private Spatial spatial;
    private DynamicPhysicsNode dynNode;
    private JBulletJoint joint;
    private JointAxis jointAxis;
    //
    // currentPos and  goalPos are used in angle
    private float radianToAngle = (float) (180 / Math.PI);
    private float angleToRadian = FastMath.PI / 180;
    private String name = "";
    private float goalPos = 0.0f;
    private float currentPos = 0.0f;
    private float intensity = 1.f;
    //
    private boolean goalAchieved = false;
    private float velocity = 0.1f;
    private float maxMotorImpulse = 10.f;
    //
    private float toleranz = 2.f;//3f; // value in degrees
    private float JOINT_EPS = 0.0000001f;
    private float minAngleLimit = -180 + getToleranz() / 2;
    private float maxAngleLimit = 180 - getToleranz() / 2;
    private float currentDiff = getMaxAngleLimit();
    //
    private Vector3f axisDirection = new Vector3f();
    //
    private RoboterCollisionObserver roboterCollisionObserver;
    //
    private boolean jointLocked = false;
    private boolean alreadyAchieved = false;
    private boolean anchored = false;
    //

    public Servo(Spatial spatial, DynamicPhysicsNode dynNode, Joint joint, RoboterCollisionObserver roboColObserver, boolean anchored) {
//    public Servo(Spatial spatial, DynamicPhysicsNode dynNode, Joint joint, boolean anchored) {
        this.spatial = spatial;
        this.dynNode = dynNode;
        roboterCollisionObserver = roboColObserver;
        this.anchored = anchored;

        if (joint instanceof JBulletJoint) {
            this.joint = (JBulletJoint) joint;
        } else {
            throw new IllegalArgumentException("works only with the Jbullet implementation");
        }

        name = dynNode.getName();

        joint.setBreakingLinearForce(1000000000);
        joint.setBreakingTorque(1000000000);


        //experiment ! how to set the values????
//        joint.setSpring(70, 10); // values from class Swing from jme-demos-physic-fun
//        joint.setSpring(0, 0);
//        joint.setSpring(Float.NaN, Float.NaN);//this should make the joint stiff !!!
//        joint.setSpring(0, 1000000000);
        //SPRING values aren´t used at the moment in the jbullet implementation of jmePhysics

        if (!dynNode.getName().equals("Brust")) {

            jointAxis = getJoint().getAxes().get(0);
            jointAxis.getDirection(axisDirection);
            axisDirection.normalize();
        }
    }

    /**
     * locks the servo, so that no movemet can be applyed on this servo
     */
    public void lockJoint() {

        if (!jointLocked) {

            jointLocked = true;

            float hingeAngle = getCurrentPos();
            float lowLim = getMinAngleLimit();
            float hiLim = getMaxAngleLimit();
            joint.enableAngularMotor(false, 0, 0);

            if (hingeAngle < lowLim) {

                jointAxis.setPositionMinimum(lowLim);
                jointAxis.setPositionMaximum(lowLim + JOINT_EPS);
            } else if (hingeAngle > hiLim) {

                jointAxis.setPositionMinimum(hiLim - JOINT_EPS);
                jointAxis.setPositionMaximum(hiLim);

            } else if (FastMath.abs(currentPos - goalPos) < toleranz) {

                jointAxis.setPositionMinimum(goalPos - JOINT_EPS);
                jointAxis.setPositionMaximum(goalPos + JOINT_EPS);

            } else {

                jointAxis.setPositionMinimum(hingeAngle - JOINT_EPS);
                jointAxis.setPositionMaximum(hingeAngle + JOINT_EPS);
            }

        }
    }

    public void unlockJoint() {
        jointLocked = false;
    }


    /**
     * Cecks for each call is the current position/angle of this servo is diffrent
     * from the goal position and if so moves the servo a bit in the correct direction.
     */
    public void update() {

        roboterCollisionObserver.checkCollisionOfInterest(this);


        if (!dynNode.getName().equals("Brust")) {


            //jointAxis.getPosition() returns radian, 1 radian = 2*PI/360°
            // therefore a transformation is needed to angle
            currentPos = jointAxis.getPosition() * radianToAngle;
            currentDiff =  FastMath.abs(currentPos - goalPos);

            if (currentDiff > getToleranz()) {
                
                jointAxis.setPositionMaximum((currentPos - 10) * angleToRadian);
                jointAxis.setPositionMinimum((currentPos + 10) * angleToRadian);


                velocity = 2f;
                maxMotorImpulse = 1000.f;


                if (currentPos > goalPos) {

                    // using enableAngularMotor() for joints you need
                    // the modified jme2Physic.jar file
                    joint.enableAngularMotor(true, -velocity, maxMotorImpulse);

                } else {

                    joint.enableAngularMotor(true, velocity, maxMotorImpulse);
                }

            }// end if (currentDiff >= getToleranz())
            else {

                joint.enableAngularMotor(false, 0.f, 0.f);

                goalAchieved =
                        true;

                lockJoint();

                jointAxis.setPositionMinimum((goalPos - JOINT_EPS) * angleToRadian);
                jointAxis.setPositionMaximum((goalPos + JOINT_EPS) * angleToRadian);

            }

//            }//end if (!isGoalAchieved())
        }// end if (!dynNode.getName().equals("Brust"))

    }

    /**
     * @return the goalPos
     */
    public float getGoalPos() {
        return goalPos;
    }

    /**
     * @param goalPos the goalPos to set
     */
    public void setGoalPos(float goalPos) {

        if (goalPos < getMinAngleLimit()) {
            goalPos = getMinAngleLimit();
            System.out.println("Servo: " + this.getName());
            System.out.println("goal position: " + goalPos + " is smaller than min angle limit for " + name);
            System.out.println("goal position set to min limit value! " + getMinAngleLimit());
        }

        if (goalPos > getMaxAngleLimit()) {
            goalPos = getMaxAngleLimit();
            System.out.println("Servo: " + this.getName());
            System.out.println("goal position: " + goalPos + " is bigger than max angle limit for " + name);
            System.out.println("goal position set to max limit value!" + getMaxAngleLimit());
        }

        this.goalPos = goalPos;
        goalAchieved =
                false;

    }

    /**
     * @return the dynNode
     */
    public DynamicPhysicsNode getDynNode() {
        return dynNode;
    }

    /**
     * @return the joint
     */
    public Joint getJoint() {
        return joint;
    }

    /**
     * @return the minAngleLimit
     */
    public float getMinAngleLimit() {
        return minAngleLimit;
    }

    /**
     * @param minAngleLimit the minAngleLimit to set
     */
    public void setMinAngleLimit(float minAngleLimit) {
        this.minAngleLimit = minAngleLimit;
    }

    /**
     * @return the maxAngleLimit
     */
    public float getMaxAngleLimit() {
        return maxAngleLimit;
    }

    /**
     * @param maxAngleLimit the maxAngleLimit to set
     */
    public void setMaxAngleLimit(float maxAngleLimit) {
        this.maxAngleLimit = maxAngleLimit;
    }

    /**
     * @return the toleranz
     */
    public float getToleranz() {
        return toleranz;
    }

    /**
     * @param toleranz the toleranz to set
     */
    public void setToleranz(float toleranz) {
        this.toleranz = toleranz;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @return the goalAchieved
     */
    public boolean isGoalAchieved() {
        return goalAchieved;
    }

    /**
     * @return the intensity
     */
    public float getIntensity() {
        return intensity;
    }

    /**
     * @param intensity the intensity to set
     */
    public void setIntensity(float intensity) {
        this.intensity = intensity;
    }

    /**
     * @return the currentPos
     */
    public float getCurrentPos() {
        return currentPos;
    }

    /**
     * @param currentPos the currentPos to set
     */
    public void setCurrentPos(float currentPos) {
        this.currentPos = currentPos;
    }

    /**
     * @return the spatial
     */
    public Spatial getSpatial() {
        return spatial;
    }
}
