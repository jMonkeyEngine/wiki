/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package arm;

import com.jme.intersection.CollisionResults;
import com.jme.intersection.TriangleCollisionResults;
import com.jmex.physics.DynamicPhysicsNode;
import java.util.ArrayList;
import java.util.HashMap;

/**
 *
 * The RoboterCollisionController observes the collisions between the servos
 * and writes the informations on the output if there was a collision of interresse
 * and which servos were involved.
 *
 * @author night
 */
public class RoboterCollisionObserver {

    private HashMap<String, Servo> servoHashMap;
    private HashMap<String, ArrayList<String>> noCollision = new HashMap<String, ArrayList<String>>();
    private ArrayList<String> keyList = new ArrayList<String>();

    public RoboterCollisionObserver() {

        // Start generating ignore combinations for collisions
        ArrayList<String> kopfList = new ArrayList<String>();
        kopfList.add("Brust");
        noCollision.put("Kopf", kopfList);

        ArrayList<String> brustList = new ArrayList<String>();
        brustList.add("Kopf");
        brustList.add("rOberarm");
        brustList.add("lOberarm");
        brustList.add("lHuefte");
        brustList.add("rHuefte");
        //erweitert / extended
//        brustList.add("lOberschenkelServo");
//        brustList.add("lOberschenkelServo");
        noCollision.put("Brust", brustList);

        //---------------------------------

        ArrayList<String> rOberarmList = new ArrayList<String>();
        rOberarmList.add("Brust");
        rOberarmList.add("rUnterarm");
        //erweitert / extended
//        rOberarmList.add("rHand");
        noCollision.put("rOberarm", rOberarmList);

        ArrayList<String> rUnterarmList = new ArrayList<String>();
        rUnterarmList.add("rHand");
        rUnterarmList.add("rOberarm");
        noCollision.put("rUnterarm", rUnterarmList);

        ArrayList<String> rHandList = new ArrayList<String>();
        rHandList.add("rUnterarm");
        //erweitert / extended
//        rHandList.add("rOberarm");
        noCollision.put("rHand", rHandList);

        //---------------------------------

        ArrayList<String> lOberarmList = new ArrayList<String>();
        lOberarmList.add("Brust");
        lOberarmList.add("lUnterarm");
        //erweitert / extended
//        lOberarmList.add("lHand");
        noCollision.put("lOberarm", lOberarmList);

        ArrayList<String> lUnterarmList = new ArrayList<String>();
        lUnterarmList.add("lHand");
        lUnterarmList.add("lOberarm");
        noCollision.put("lUnterarm", lUnterarmList);

        ArrayList<String> lHandList = new ArrayList<String>();
        lHandList.add("lUnterarm");
        //erweitert / extended
//        lHandList.add("lOberarm");
        noCollision.put("lHand", lHandList);

        //---------------------------------

        ArrayList<String> lHuefteList = new ArrayList<String>();
        lHuefteList.add("Brust");
        lHuefteList.add("lOberschenkelServo");
        noCollision.put("lHuefte", lHuefteList);

        ArrayList<String> lOberschenkelServoList = new ArrayList<String>();
        lOberschenkelServoList.add("lHuefte");
        lOberschenkelServoList.add("lOberschenkel");
        //erweitert / extended
//        lOberschenkelServoList.add("Brust");
        noCollision.put("lOberschenkelServo", lOberschenkelServoList);

        ArrayList<String> lOberschenkelList = new ArrayList<String>();
        lOberschenkelList.add("lUnterschenkel");
        lOberschenkelList.add("lOberschenkelServo");
        noCollision.put("lOberschenkel", lOberschenkelList);

        ArrayList<String> lUnterschenkelList = new ArrayList<String>();
        lUnterschenkelList.add("lFussServo");
        lUnterschenkelList.add("lOberschenkel");
        noCollision.put("lUnterschenkel", lUnterschenkelList);

        ArrayList<String> lFussServoList = new ArrayList<String>();
        lFussServoList.add("lFuss");
        lFussServoList.add("lUnterschenkel");
        noCollision.put("lFussServo", lFussServoList);

        ArrayList<String> lFussList = new ArrayList<String>();
        lFussList.add("lFussServo");
        noCollision.put("lFuss", lFussList);

        //---------------------------------

        ArrayList<String> rHuefteList = new ArrayList<String>();
        rHuefteList.add("Brust");
        rHuefteList.add("rOberschenkelServo");
        noCollision.put("rHuefte", rHuefteList);

        ArrayList<String> rOberschenkelServoList = new ArrayList<String>();
        rOberschenkelServoList.add("rHuefte");
        rOberschenkelServoList.add("rOberschenkel");
        //erweitert / extended
//        rOberschenkelServoList.add("Brust");
        noCollision.put("rOberschenkelServo", rOberschenkelServoList);

        ArrayList<String> rOberschenkelList = new ArrayList<String>();
        rOberschenkelList.add("rUnterschenkel");
        rOberschenkelList.add("rOberschenkelServo");
        noCollision.put("rOberschenkel", rOberschenkelList);

        ArrayList<String> rUnterschenkelList = new ArrayList<String>();
        rUnterschenkelList.add("rFussServo");
        rUnterschenkelList.add("rOberschenkel");
        noCollision.put("rUnterschenkel", rUnterschenkelList);

        ArrayList<String> rFussServoList = new ArrayList<String>();
        rFussServoList.add("rFuss");
        rFussServoList.add("rUnterschenkel");
        noCollision.put("rFussServo", rFussServoList);

        ArrayList<String> rFussList = new ArrayList<String>();
        rFussList.add("rFussServo");
        noCollision.put("rFuss", rFussList);

        //---------------------------------

        keyList.addAll(noCollision.keySet());
    }

    /**
     * checks if there is a rule for source and target
     * if so the collision is ignored and false is returned
     * @param source first involved part
     * @param target second involved part
     * @return true if collision combination is not between two neighbour parts
     */
    public boolean checkCollisionOfInterest(String source, String target) {

//        System.out.println("checkCollisionOfInterest STRING "+source +" "+ target);

        boolean interestingCollision = false;

        if (keyList.contains(source)) {

            if (noCollision.get(source).contains(target)) {
                /* do nothing / ignore
                 * collision is between neighbour parts
                 * which we are not interessted in
                 */
            } else {
                //  ! ! ! HERE´S THE PLACE WERE COLLISION DETECTION OUTPUT IS GENERATED   ! ! !
                System.out.println("Collision detected between:");
                System.out.println(source +" & "+ target +"\n");
                interestingCollision = true;
            }

        } else {
            System.out.println("the name of source in checkCollisionOfInterest()" +
                    " is not part of the observed robotparts.");
        }

        return interestingCollision;
    }

    /**
     * checks if there is a rule for source and target.
     * calls checkCollisionOfInterest(String source, String target).
     * (if not the movement of the servos is stopped by setting the current
     * position of the servos to the new goal positions.) <-> DEACTIVATED !!
     * @param source first involved part
     * @param target second involved part
     * @return true if collision combination is not between two neighbour parts
     */
    public boolean checkCollisionOfInterest(Servo source, Servo target) {

//        System.out.println("checkCollisionOfInterest SERVO "+source.getName() +" "+ target.getName());

        boolean interestingCollision = false;
        interestingCollision = checkCollisionOfInterest(source.getName(), target.getName());

//        /* stop the moving which lead to the collision
//         * if it was one of interest
//         */
//        if (interestingCollision) {
//            source.setGoalPos(source.getCurrentPos());
//
//            JBulletJoint joint;
//
//            if (source.getJoint() instanceof JBulletJoint) {
//                joint = (JBulletJoint) source.getJoint();
//                joint.enableAngularMotor(false, 0.f, 0.f);
//            } else {
//                throw new IllegalArgumentException("works only with the Jbullet implementation");
//            }
//
//            target.setGoalPos(target.getCurrentPos());
//
//            if (target.getJoint() instanceof JBulletJoint) {
//                joint = (JBulletJoint) source.getJoint();
//                joint.enableAngularMotor(false, 0.f, 0.f);
//            } else {
//                throw new IllegalArgumentException("works only with the Jbullet implementation");
//            }
//        }


        return interestingCollision;
    }

    /**
     * Checks with TriangleAccuracity if there are collisions with the corresponding
     * DynamicPhysicsNode of the Servo.
     * Calls for each collision result the methode checkCollisionOfInterest(Servo source, Servo target).
     *
     * @param servo which should be checked for collisions
     */
    public void checkCollisionOfInterest(Servo servo) {

//        System.out.println("checkCollisionOfInterest SERVO "+ servo.getName());

        DynamicPhysicsNode dynNode = servo.getDynNode();

//        CollisionResults results = new BoundingCollisionResults();
        CollisionResults results = new TriangleCollisionResults();
        results.clear();
        //dynNode.getParent() is rootNode ; see in Main in addRoboPart() -> rootNode.attachChild(dynPhysNode);
        dynNode.findCollisions(dynNode.getParent(), results);

        if (results.getNumber() > 0) {

            for (int i = 0; i < results.getNumber(); i++) {

//                System.out.println("result "+i+" dynNode "+ dynNode.getName() );
//                System.out.println( i + " "+ results.getCollisionData(i).getSourceMesh().getName() );
//                System.out.println( i + " "+ results.getCollisionData(i).getTargetMesh().getName() );


                checkCollisionOfInterest(servo, servoHashMap.get(results.getCollisionData(i).getTargetMesh().getName()));
            }
        }
    }

    /**
     * @return the servoHashMap
     */
    public HashMap<String, Servo> getServoHashMap() {
        return servoHashMap;
    }

    /**
     * @param servoHashMap the servoHashMap to set
     */
    public void setServoHashMap(HashMap<String, Servo> servoHashMap) {
        this.servoHashMap = servoHashMap;
    }
}

