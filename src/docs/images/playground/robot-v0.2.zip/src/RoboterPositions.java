/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package arm;

import java.util.ArrayList;

/**
 *
 * 
 * An ArrayList of all stored RoboterPositions.
 *
 * call add(roboPos) to add new RoboterPositions to the untill then stored Positions.
 *
 * @author night
 */
public class RoboterPositions extends ArrayList<RoboterPosition>{

}
