/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package arm;

import com.jme.bounding.OrientedBoundingBox;
import com.jme.math.Vector3f;
import com.jme.scene.Node;
import com.jme.scene.Spatial;
import com.jme.system.DisplaySystem;
import com.jmex.physics.CollisionGroup;
import com.jmex.physics.DynamicPhysicsNode;
import com.jmex.physics.Joint;
import com.jmex.physics.PhysicsSpace;
import com.jmex.physics.RotationalJointAxis;
import com.jmex.physics.StaticPhysicsNode;
import com.jmex.physics.callback.FrictionCallback;
import com.jmex.physics.material.Material;
import java.io.File;

/**
 * This class loads the spatials from "name"-jme.xml and builds
 * a physical representation of the model.
 *
 * Create an instanze and call robot.init() to create a new working robot.
 *
 * @author night
 */
public class Roboter {

    //
    private Node rootNode;
    private PhysicsSpace physicsSpace;
    private StaticPhysicsNode floor;
    //
    private float mass = 0.1f;
    private float scale = 1.0f;
    //    private boolean boxModel = false;
    private boolean boxModel = true;
    private boolean anchored = false;
    //
    private File modelFile;
    private Node modelFileNode;
    //
    private Vector3f xAchse = new Vector3f(1, 0, 0);
    private Vector3f yAchse = new Vector3f(0, 1, 0);
    private Vector3f zAchse = new Vector3f(0, 0, 1);
    //
    private RoboterPositionController roboterPositionController;
    private RoboterCollisionObserver roboterCollisionObserver;
    private RoboterCollisionController roboterCollisionController;
    private DisplaySystem display;


    public Roboter(Node rootNode, PhysicsSpace physicsSpace, StaticPhysicsNode floor,
            RoboterPositionController roboPosControl, boolean anchored, DisplaySystem display) {

        this.rootNode = rootNode;
        this.physicsSpace = physicsSpace;
        this.floor = floor;


        roboterPositionController = roboPosControl;
        roboterCollisionObserver = new RoboterCollisionObserver();
        roboterCollisionController = new RoboterCollisionController(physicsSpace, floor);

        this.anchored = anchored;

        this.display = display;
    }

    /**
     * Creates all parts (Servos) of the robot and stores them into the HashMap of
     * RoboterPositionController and initialize roboPosition- and roboCollisionController.
     */
    public void init() {

        if (boxModel) {
            modelFile = new File("data/roboterblau-jme.xml");

        } else {
            modelFile = new File("src/roboter-jme.xml");
        }
        modelFileNode = XMLLoader.load(modelFile);

        //--------------

        roboterPositionController.getServoHashMap().put("Brust", addRoboterPart("Brust", 0.415f, null, null));

        roboterPositionController.getServoHashMap().put("Kopf", addRoboterPart("Kopf", 0.055f, yAchse,
                roboterPositionController.getServoHashMap().get("Brust").getDynNode()));
        //-------------------------
        roboterPositionController.getServoHashMap().put("rOberarm", addRoboterPart("rOberarm", 0.100f, xAchse.mult(-1),
                roboterPositionController.getServoHashMap().get("Brust").getDynNode()));

        roboterPositionController.getServoHashMap().put("rUnterarm", addRoboterPart("rUnterarm", 0.055f, yAchse.mult(-1),
                roboterPositionController.getServoHashMap().get("rOberarm").getDynNode()));

        roboterPositionController.getServoHashMap().put("rHand", addRoboterPart("rHand", 0.015f, xAchse.mult(-1),
                roboterPositionController.getServoHashMap().get("rUnterarm").getDynNode()));
        //-------------------------
        roboterPositionController.getServoHashMap().put("lOberarm", addRoboterPart("lOberarm", 0.100f, xAchse,
                roboterPositionController.getServoHashMap().get("Brust").getDynNode()));

        roboterPositionController.getServoHashMap().put("lUnterarm", addRoboterPart("lUnterarm", 0.055f, yAchse,
                roboterPositionController.getServoHashMap().get("lOberarm").getDynNode()));

        roboterPositionController.getServoHashMap().put("lHand", addRoboterPart("lHand", 0.015f, xAchse,
                roboterPositionController.getServoHashMap().get("lUnterarm").getDynNode()));
        //-------------------------
        roboterPositionController.getServoHashMap().put("lHuefte", addRoboterPart("lHuefte", 0.015f, yAchse,
                roboterPositionController.getServoHashMap().get("Brust").getDynNode()));

        roboterPositionController.getServoHashMap().put("lOberschenkelServo", addRoboterPart("lOberschenkelServo", 0.085f, xAchse,
                roboterPositionController.getServoHashMap().get("lHuefte").getDynNode()));

        roboterPositionController.getServoHashMap().put("lOberschenkel", addRoboterPart("lOberschenkel", 0.060f, zAchse,
                roboterPositionController.getServoHashMap().get("lOberschenkelServo").getDynNode()));

        roboterPositionController.getServoHashMap().put("lUnterschenkel", addRoboterPart("lUnterschenkel", 0.015f, zAchse,
                roboterPositionController.getServoHashMap().get("lOberschenkel").getDynNode()));

        roboterPositionController.getServoHashMap().put("lFussServo", addRoboterPart("lFussServo", 0.090f, zAchse,
                roboterPositionController.getServoHashMap().get("lUnterschenkel").getDynNode()));

        roboterPositionController.getServoHashMap().put("lFuss", addRoboterPart("lFuss", 0.030f, xAchse,
                roboterPositionController.getServoHashMap().get("lFussServo").getDynNode()));
        //-------------------------
        roboterPositionController.getServoHashMap().put("rHuefte", addRoboterPart("rHuefte", 0.015f, yAchse,
                roboterPositionController.getServoHashMap().get("Brust").getDynNode()));

        roboterPositionController.getServoHashMap().put("rOberschenkelServo", addRoboterPart("rOberschenkelServo", 0.085f, xAchse.mult(-1),
                roboterPositionController.getServoHashMap().get("rHuefte").getDynNode()));

        roboterPositionController.getServoHashMap().put("rOberschenkel", addRoboterPart("rOberschenkel", 0.060f, zAchse,
                roboterPositionController.getServoHashMap().get("rOberschenkelServo").getDynNode()));

        roboterPositionController.getServoHashMap().put("rUnterschenkel", addRoboterPart("rUnterschenkel", 0.015f, zAchse,
                roboterPositionController.getServoHashMap().get("rOberschenkel").getDynNode()));

        roboterPositionController.getServoHashMap().put("rFussServo", addRoboterPart("rFussServo", 0.090f, zAchse,
                roboterPositionController.getServoHashMap().get("rUnterschenkel").getDynNode()));

        roboterPositionController.getServoHashMap().put("rFuss", addRoboterPart("rFuss", 0.030f, xAchse.mult(-1),
                roboterPositionController.getServoHashMap().get("rFussServo").getDynNode()));
        //-------------------

        roboterPositionController.init();
        roboterPositionController.resetPositionPointer();
        roboterPositionController.currentPosition();

        roboterCollisionObserver.setServoHashMap(roboterPositionController.getServoHashMap());
        roboterCollisionController.setServoHashMap(roboterPositionController.getServoHashMap());

    }

   
    public Servo addRoboterPart(
            String name,
            Vector3f direction,
            DynamicPhysicsNode addToNode) {

        return addRoboterPart(name, mass, direction, addToNode);
    }

    public Servo addRoboterPart(
            String name,
            float mass,
            Vector3f direction,
            DynamicPhysicsNode addToNode) {

        System.out.println("RoboPart: " + name);

        Spatial spatial = modelFileNode.getChild(name);
        spatial.setLocalScale(scale / 10);
        spatial.setName(name);

        Vector3f spatialPos = spatial.getLocalTranslation();
        spatial.setLocalTranslation(new Vector3f(0, 0, 0));

        DynamicPhysicsNode dynPhysNode = physicsSpace.createDynamicNode();
        dynPhysNode.attachChild(spatial);
        dynPhysNode.setLocalScale(scale);

//        Material m = Material.PLASTIC;
        Material m = Material.IRON;
//        m.setDensity(0.001f);
        dynPhysNode.setMaterial(m);

        System.out.println("boxModel: " + boxModel);
        if (boxModel) {

            spatial.setModelBound(new OrientedBoundingBox());
            spatial.updateModelBound();

//            dynPhysNode.generatePhysicsGeometry(false);
            dynPhysNode.generatePhysicsGeometry();

        } else {
            dynPhysNode.generatePhysicsGeometry(true);
        }

        dynPhysNode.setName(name);

        //necessary to apply the collisionGroup Rulles which are created in RoboterCollisionGroup
        CollisionGroup collGrp = roboterCollisionController.getCollisionGroups().get(name);

        dynPhysNode.setCollisionGroup(collGrp);

//        dynPhysNode.setMass(mass);
//        dynPhysNode.setMass(mass*1000);
//        dynPhysNode.setMass(this.mass);
        dynPhysNode.setMass(50);


        if (name.equals("Kopf") || name.contains("Hand")) {
            dynPhysNode.setMass(10f);
        }

        rootNode.attachChild(dynPhysNode);
        spatial.updateRenderState();


        dynPhysNode.getLocalTranslation().set(spatialPos);

        Joint joint = physicsSpace.createJoint();
        joint.setActive(true);
//        joint.setCollisionEnabled(false);
        joint.setCollisionEnabled(true);//seems to be less wiggling with the hip if active, hm ????

        joint.setName(name);

        Spatial anchorSpatial = modelFileNode.getChild("h" + name);
        Vector3f anchorPos = new Vector3f(anchorSpatial.getLocalTranslation());
//        System.out.println("h"+name + "position "+anchorSpatial.getWorldTranslation().toString());
        // sout -> (0, 0, 0) for all hSpatialPos

        // if anchor with two nodes then use anchorPos relative to node#1
        if (addToNode != null) {
            anchorPos = anchorSpatial.getLocalTranslation().subtract(addToNode.getLocalTranslation());
        }

        joint.setAnchor(anchorPos);

        dynPhysNode.setCenterOfMass(dynPhysNode.getWorldTranslation());

        if (direction != null) {

            RotationalJointAxis rotationAxis = joint.createRotationalAxis();
            rotationAxis.setDirection(direction);
        }


        if (anchored) {
            // values for friction (= Reibung) - first FORCE, second ANGULAR
            // angular seems to have no effect, (/force fuer Luftwiederstand)
            FrictionCallback fcb = new FrictionCallback();
            fcb.add(dynPhysNode, 3, 0);//Float.MAX_VALUE);
            physicsSpace.addToUpdateCallbacks(fcb);
        }

        // if anchor with two nodes then use anchorPos relative to node#1
        if (addToNode != null) {
            joint.attach(addToNode, dynPhysNode);
//            joint.setActive(true);
            // disable collision detection between joint bodies
//            joint.setCollisionEnabled(false);

        } else {
            /*if the following line isn´t commented out 
            (means codeline is used) or (anchored = true)
            the thorax will be pinned into the air,
            that means the whole body will not fall on the ground*/
            if (anchored) {
                joint.attach(dynPhysNode);
            }
        }

        return new Servo(spatial, dynPhysNode, joint, roboterCollisionObserver, anchored);
//        return new Servo(spatial, dynPhysNode, joint, anchored);
    }

    /**
     * @return the roboPosController
     */
    public RoboterPositionController getRoboPosController() {
        return roboterPositionController;
    }

    /**
     * @return the roboterCollisionController
     */
    public RoboterCollisionController getRoboterCollisionController2() {
        return roboterCollisionController;
    }

    /**
     * This function removes the whole robot from the scene graph of jme
     * or rather from the simulation.
     * There being removed all physical and visual components of the robot.
     */
    public void detach() {

        System.out.println(">> Detaching Robot");

        for (Servo s : roboterPositionController.getServoHashMap().values()) {

            s.getSpatial().removeFromParent();

            s.getJoint().detach();

            s.getDynNode().removeFromParent();
            s.getDynNode().delete();
        }

    }
}
