/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package arm;

import java.beans.XMLDecoder;
import java.beans.XMLEncoder;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.HashMap;

/**
 *
 * Sets the at the moment valid RoboterPositions.
 * Call roboPosController.nextGoalPosition() if the robot should apply the next
 * stored position.
 *
 * @author night
 */
public class RoboterPositionController {

    private float kopfIntesity = 1.f;
    private float oberarmIntesity = 3.f;
    private float unterarmIntesity = 2.f;
    private float handIntesity = 1.f;
    private float huefteIntesity = 2.f;
    private float oberSchenkelServoIntesity = 4.f;
    private float oberSchenkelIntesity = 5f;
    private float unterSchenkelIntesity = 5f;
    private float fussServoIntesity = 5f;
    private float fussIntesity = 3.f;
    //
    private HashMap<String, Servo> servoHashMap = new HashMap<String, Servo>();
    private boolean allServosGoalAchieved = false;
    //
    public RoboterPositions positions = new RoboterPositions();
    private int positionPointer = 0;

    public void addRoboterPosition(RoboterPosition pos) {
        positions.add(pos);
    }

    public void removeRoboterPosition(RoboterPosition pos) {
        positions.remove(pos);
    }

    public void resetPositionPointer() {
        positionPointer = 0;
    }

    public void currentPosition() {
        setGoalPosition(positions.get(positionPointer));
    }

    public void nextGoalPosition() {
        if (positionPointer < positions.size() - 1) {
            positionPointer++;
            setGoalPosition(positions.get(positionPointer));
        } else {
            positionPointer = 0;
            setGoalPosition(positions.get(positionPointer));
        }
    }

    public void previousGoalPosition() {
        if (positionPointer > 0) {
            positionPointer--;
            setGoalPosition(positions.get(positionPointer));
        } else {
            positionPointer = positions.size() - 1;
            setGoalPosition(positions.get(positionPointer));
        }
    }

    public void setGoalPosition(RoboterPosition pos) {
        if (pos != null) {
            getServoHashMap().get("Kopf").setGoalPos(pos.getKopfPos());

            getServoHashMap().get("rOberarm").setGoalPos(pos.getROberarmPos());
            getServoHashMap().get("rUnterarm").setGoalPos(pos.getRUnterarmPos());
            getServoHashMap().get("rHand").setGoalPos(pos.getRHandPos());

            getServoHashMap().get("lOberarm").setGoalPos(pos.getLOberarmPos());
            getServoHashMap().get("lUnterarm").setGoalPos(pos.getLUnterarmPos());
            getServoHashMap().get("lHand").setGoalPos(pos.getLHandPos());

            getServoHashMap().get("lHuefte").setGoalPos(pos.getLHueftePos());
            getServoHashMap().get("lOberschenkelServo").setGoalPos(pos.getLOberschenkelServoPos());
            getServoHashMap().get("lOberschenkel").setGoalPos(pos.getLOberschenkelPos());
            getServoHashMap().get("lUnterschenkel").setGoalPos(pos.getLUnterschenkelPos());
            getServoHashMap().get("lFussServo").setGoalPos(pos.getLFussServoPos());
            getServoHashMap().get("lFuss").setGoalPos(pos.getLFussPos());

            getServoHashMap().get("rHuefte").setGoalPos(pos.getRHueftePos());
            getServoHashMap().get("rOberschenkelServo").setGoalPos(pos.getROberschenkelServoPos());
            getServoHashMap().get("rOberschenkel").setGoalPos(pos.getROberschenkelPos());
            getServoHashMap().get("rUnterschenkel").setGoalPos(pos.getRUnterschenkelPos());
            getServoHashMap().get("rFussServo").setGoalPos(pos.getRFussServoPos());
            getServoHashMap().get("rFuss").setGoalPos(pos.getRFussPos());

//            System.out.println( pos.toString() );
            

        } else {
            System.out.println(">> NO position!");
        }
    }

    /**
     * THIS METHOD SHOULD BE CALLED AFTER ALL SERVOS ARE ADDED TO THE HASHMAP !!!!
     *
     * sets the default values for the angle and the intensity of the servos.
     */
    public void init() {

        /*no init for Servo with name "Brust" needed*/
        getServoHashMap().get("Kopf").setIntensity(kopfIntesity);

        getServoHashMap().get("rOberarm").setIntensity(oberarmIntesity);
        getServoHashMap().get("rUnterarm").setIntensity(unterarmIntesity);
        getServoHashMap().get("rHand").setIntensity(handIntesity);

        getServoHashMap().get("lOberarm").setIntensity(oberarmIntesity);
        getServoHashMap().get("lUnterarm").setIntensity(unterarmIntesity);
        getServoHashMap().get("lHand").setIntensity(handIntesity);

        getServoHashMap().get("lHuefte").setIntensity(huefteIntesity);
        getServoHashMap().get("lOberschenkelServo").setIntensity(oberSchenkelServoIntesity);
        getServoHashMap().get("lOberschenkel").setIntensity(oberSchenkelIntesity);
        getServoHashMap().get("lUnterschenkel").setIntensity(unterSchenkelIntesity);
        getServoHashMap().get("lFussServo").setIntensity(fussServoIntesity);
        getServoHashMap().get("lFuss").setIntensity(fussIntesity);

        getServoHashMap().get("rHuefte").setIntensity(huefteIntesity);
        getServoHashMap().get("rOberschenkelServo").setIntensity(oberSchenkelServoIntesity);
        getServoHashMap().get("rOberschenkel").setIntensity(oberSchenkelIntesity);
        getServoHashMap().get("rUnterschenkel").setIntensity(unterSchenkelIntesity);
        getServoHashMap().get("rFussServo").setIntensity(fussServoIntesity);
        getServoHashMap().get("rFuss").setIntensity(fussIntesity);
    }

    /**
     * Sets the angle which the servo should achieve.
     *
     * @param name of the servo.
     * @param angle that should be achieved. should be -360° < angle < 360°.
     * @return true if the value of the angle is allowed and a servo exist with the given name.
     */
    public boolean setGoalAngle(String name, float angle) {
        boolean succes = false;

        if (angle <= -360.f) {
            System.out.println("The angle is smaller than or equals -360°.");
            return succes;
        }

        if (angle >= 360.f) {
            System.out.println("The angle is bigger than or equals 360°.");
            return succes;
        }

        Servo servo = getServoHashMap().get(name);

        if (servo != null) {
            succes = true;
//            servo.setGoalPos(angle * radianToAngle);
            servo.setGoalPos(angle);
        }

        return succes;
    }

    /**
     * Calls update() on all servos which are controlled by an instance of this class.
     */
    public void update() {
        /* set allServos.. true, because only if all isGoalAchieved() are true
        allServos staies true else it is false*/
        allServosGoalAchieved = true;

        for (Servo servo : getServoHashMap().values()) {

            // don´t make update if the servo is used for "Brust"
            if (!servo.getName().equals("Brust")) {

                servo.update();
                allServosGoalAchieved = (isAllServosGoalAchieved() && servo.isGoalAchieved());
            }
        }

//        if(allServosGoalAchieved){
//        nextGoalPosition();
//        }
    }

    /**
     * @return the kopfIntesity
     */
    public float getKopfIntesity() {
        return kopfIntesity;
    }

    /**
     * @param kopfIntesity the kopfIntesity to set
     */
    public void setKopfIntesity(float kopfIntesity) {
        this.kopfIntesity = kopfIntesity;
    }

    /**
     * @return the oberarmIntesity
     */
    public float getOberarmIntesity() {
        return oberarmIntesity;
    }

    /**
     * @param oberarmIntesity the oberarmIntesity to set
     */
    public void setOberarmIntesity(float oberarmIntesity) {
        this.oberarmIntesity = oberarmIntesity;
    }

    /**
     * @return the unterarmIntesity
     */
    public float getUnterarmIntesity() {
        return unterarmIntesity;
    }

    /**
     * @param unterarmIntesity the unterarmIntesity to set
     */
    public void setUnterarmIntesity(float unterarmIntesity) {
        this.unterarmIntesity = unterarmIntesity;
    }

    /**
     * @return the handIntesity
     */
    public float getHandIntesity() {
        return handIntesity;
    }

    /**
     * @param handIntesity the handIntesity to set
     */
    public void setHandIntesity(float handIntesity) {
        this.handIntesity = handIntesity;
    }

    /**
     * @return the huefteIntesity
     */
    public float getHuefteIntesity() {
        return huefteIntesity;
    }

    /**
     * @param huefteIntesity the huefteIntesity to set
     */
    public void setHuefteIntesity(float huefteIntesity) {
        this.huefteIntesity = huefteIntesity;
    }

    /**
     * @return the oberSchenkelServoIntesity
     */
    public float getOberSchenkelServoIntesity() {
        return oberSchenkelServoIntesity;
    }

    /**
     * @param oberSchenkelServoIntesity the oberSchenkelServoIntesity to set
     */
    public void setOberSchenkelServoIntesity(float oberSchenkelServoIntesity) {
        this.oberSchenkelServoIntesity = oberSchenkelServoIntesity;
    }

    /**
     * @return the oberSchenkelIntesity
     */
    public float getOberSchenkelIntesity() {
        return oberSchenkelIntesity;
    }

    /**
     * @param oberSchenkelIntesity the oberSchenkelIntesity to set
     */
    public void setOberSchenkelIntesity(float oberSchenkelIntesity) {
        this.oberSchenkelIntesity = oberSchenkelIntesity;
    }

    /**
     * @return the unterSchenkelIntesity
     */
    public float getUnterSchenkelIntesity() {
        return unterSchenkelIntesity;
    }

    /**
     * @param unterSchenkelIntesity the unterSchenkelIntesity to set
     */
    public void setUnterSchenkelIntesity(float unterSchenkelIntesity) {
        this.unterSchenkelIntesity = unterSchenkelIntesity;
    }

    /**
     * @return the fussServoIntesity
     */
    public float getFussServoIntesity() {
        return fussServoIntesity;
    }

    /**
     * @param fussServoIntesity the fussServoIntesity to set
     */
    public void setFussServoIntesity(float fussServoIntesity) {
        this.fussServoIntesity = fussServoIntesity;
    }

    /**
     * @return the fussIntesity
     */
    public float getFussIntesity() {
        return fussIntesity;
    }

    /**
     * @param fussIntesity the fussIntesity to set
     */
    public void setFussIntesity(float fussIntesity) {
        this.fussIntesity = fussIntesity;
    }

    /**
     * @return the servoHashMap
     */
    public HashMap<String, Servo> getServoHashMap() {
        return servoHashMap;
    }

    /**
     * @return the allServosGoalAchieved
     */
    public boolean isAllServosGoalAchieved() {
        return allServosGoalAchieved;
    }

    public void loadPositions(File f) throws FileNotFoundException {
        XMLDecoder d = new XMLDecoder(new FileInputStream(f));
        positions = (RoboterPositions) d.readObject();
        d.close();
    }

    public void savePositions(File f) throws FileNotFoundException {
        XMLEncoder e = new XMLEncoder(new FileOutputStream(f));
        e.writeObject(positions);
        e.close();
    }

    /**
     * @param servoHashMap the servoHashMap to set
     */
    public void setServoHashMap(HashMap<String, Servo> servoHashMap) {
        this.servoHashMap = servoHashMap;
    }
}
