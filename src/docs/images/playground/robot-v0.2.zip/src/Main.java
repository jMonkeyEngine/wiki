
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package arm;

import com.jme.image.Texture;
import com.jme.input.InputHandler;
import com.jme.input.KeyInput;
import com.jme.input.action.InputAction;
import com.jme.input.action.InputActionEvent;
import com.jme.math.Quaternion;
import com.jme.math.Vector3f;
import com.jme.scene.Spatial;
import com.jme.scene.shape.Box;
import com.jme.scene.state.TextureState;
import com.jme.util.TextureManager;
import com.jmex.physics.DynamicPhysicsNode;
import com.jmex.physics.PhysicsSpace;
import com.jmex.physics.StaticPhysicsNode;
//import com.jmex.physics.util.SimplePhysicsGame;
import java.io.File;
import java.io.FileNotFoundException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Main extends SimpleRobotGame {
//public class Main extends SimplePhysicsGame {

    private StaticPhysicsNode floor;
    private Roboter roboter;
    private RoboterPositionController roboterPositionController;
    //
    private File positionFile = new File("data/positionen01.xml");
    private long positionFileLastModified;
//

    public static void main(String[] args) {

        Main app = new Main();
        app.setConfigShowMode(ConfigShowMode.NeverShow);
//        app.setConfigShowMode(ConfigShowMode.AlwaysShow);

        PhysicsSpace.chooseImplementation("JBullet");

        app.start(); // Start the program
    }

    protected void simpleInitGame() {

        getPhysicsSpace().setAccuracy(0.007f);

        cam.setLocation(new Vector3f(-5, 5, 0));
        cam.lookAt(new Vector3f(3, 0, 0), new Vector3f(0, 1, 0)); // (0,1,0) = yAchse is worldup

        //*************** Boden BEGIN //***************
        floor = getPhysicsSpace().createStaticNode();
        rootNode.attachChild(floor);

//        final Box visualFloorBox = new Box("floor", new Vector3f(0, -0.25f, 0), 15, 0.25f, 15);
        final Box visualFloorBox = new Box("floor", new Vector3f(0, -0.55f, 0), 15, 0.25f, 15);
        floor.attachChild(visualFloorBox);
        floor.generatePhysicsGeometry();

        URL urlToPicture = null;
        try {
            urlToPicture = new File("data/Fieldstone.jpg").toURI().toURL();

        } catch (MalformedURLException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        }

        Texture texture = TextureManager.loadTexture(
                urlToPicture,
                Texture.MinificationFilter.BilinearNearestMipMap,
                Texture.MagnificationFilter.Bilinear);


        TextureState ts = display.getRenderer().createTextureState();
        ts.setEnabled(true);
        ts.setTexture(texture);

        //set the configurations for the used Texure
        ts.getTexture().setWrap(Texture.WrapMode.Repeat);
        visualFloorBox.scaleTextureCoordinates(0, 10f);

        visualFloorBox.setRenderState(ts);
        //*************** Boden END //***************

        //*************** Set Positions BEGIN //***************
        roboterPositionController = new RoboterPositionController();

        

        RoboterPosition pos1 = new RoboterPosition();
        pos1.setLOberarmPos(70f);
        pos1.setROberarmPos(70f);
        pos1.setKopfPos(45.f);
        roboterPositionController.addRoboterPosition(pos1);

        RoboterPosition pos2 = new RoboterPosition();
        pos2.setLHueftePos(-45f);
        pos2.setRHueftePos(45f);
//        pos2.setKopfPos(-25.f);
        roboterPositionController.addRoboterPosition(pos2);

        RoboterPosition pos3 = new RoboterPosition();
        pos3.setLOberarmPos(45f);
        pos3.setROberarmPos(45f);
        pos3.setLUnterarmPos(50f);
        pos3.setRUnterarmPos(50f);
        pos3.setLOberschenkelPos(-30f);
        pos3.setROberschenkelPos(30f);
        pos3.setLFussServoPos(30f);
        pos3.setRFussServoPos(-30f);
//        pos3.setKopfPos(0.f);
        roboterPositionController.addRoboterPosition(pos3);

        RoboterPosition nullPosition = new RoboterPosition();
        roboterPositionController.addRoboterPosition(nullPosition);

        RoboterPosition pos5 = new RoboterPosition();
        pos5.setKopfPos(20.f);
        pos5.setLOberschenkelPos(30f);
        pos5.setROberschenkelPos(-30f);
        pos5.setLFussServoPos(-30f);
        pos5.setRFussServoPos(30f);
        roboterPositionController.addRoboterPosition(pos5);

        RoboterPosition pos6 = new RoboterPosition();
        pos6.setLOberarmPos(90f);
        pos6.setROberarmPos(90f);
        roboterPositionController.addRoboterPosition(pos6);


        //*************** Set First Roboter Instance START //***************
        // if you load positions from file comment the following two lines out
        // and use the load block
        roboter = new Roboter(rootNode, getPhysicsSpace(), floor, roboterPositionController, false, display);
        roboter.init();
        //*************** Set First Roboter Instance END //***************

        // Stores the generated position in a file
        try {
            roboterPositionController.savePositions(positionFile);
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        //*************** Set Positions END //***************


//        /* --- IF YOU WANT TO LOAD FROM FILE START --- */
//        try {
//            roboter = new Roboter(rootNode, getPhysicsSpace(), floor, roboterPositionController, false, display);
//            roboterPositionController.loadPositions(positionFile);
//            roboter.init();
//            System.out.println("SIZE of positions: " + roboter.getRoboPosController().positions.size());
//
//        } catch (FileNotFoundException ex) {
//            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
//        }
//
//        /* --- IF YOU WANT TO LOAD FROM FILE END --- */



        //---------- Check for modification in positionFile START ----------//

        positionFileLastModified = positionFile.lastModified();

        /*
         * Check if the file from which was loaded was modified.
         * If load the file again, set the position pointer/counter to zero and
         * use the current position.
         *
         * ATTENTION: if you you´re not aloud to deleted the file temporally.
         *            this could be the case if you use copy & paste from your
         *            OS (Mac/Win/Linux).
         */
        Thread loadThread = new Thread(new Runnable() {

            public void run() {

                System.out.println("thread run");

//                while (positionFile.exists()) {
                while (positionFile.isFile()) {

                    if (positionFile.lastModified() != positionFileLastModified) {

                        try {
                            roboter.getRoboPosController().loadPositions(positionFile);

                            positionFileLastModified = positionFile.lastModified();
                            roboter.getRoboPosController().resetPositionPointer();
                            roboter.getRoboPosController().currentPosition();

                        } catch (FileNotFoundException ex) {
                            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
                            System.out.println("Couldn´t load modified position file!");
                        }
                    }//end if()

                }//end while( exists() )
            }
        });

        loadThread.start();

        //---------- Check for modification in positionFile END ----------//



        //---------- Set the keyboard shortcuts START ----------//

        input.addAction(new InputAction() {

            public void performAction(InputActionEvent evt) {
                if (evt.getTriggerPressed()) {
                    roboter.getRoboPosController().nextGoalPosition();
                }
            }
        }, InputHandler.DEVICE_KEYBOARD, KeyInput.KEY_0, InputHandler.AXIS_NONE, false);


        input.addAction(new InputAction() {

            public void performAction(InputActionEvent evt) {
                if (evt.getTriggerPressed()) {
                    roboter.getRoboPosController().previousGoalPosition();
                }
            }
        }, InputHandler.DEVICE_KEYBOARD, KeyInput.KEY_9, InputHandler.AXIS_NONE, false);


        //reset option to set robot to start Position without anchor
        input.addAction(new InputAction() {

            public void performAction(InputActionEvent evt) {
                if (evt.getTriggerPressed()) {

//                    System.out.println("SPACE :-) before detach");
                    roboter.detach();
//                    System.out.println("SPACE :-) after detach");

                    roboter = new Roboter(rootNode,
                            getPhysicsSpace(), floor,
                            roboterPositionController, false,
                            display);

                    roboter.init();
                }
            }
        }, InputHandler.DEVICE_KEYBOARD, KeyInput.KEY_1, InputHandler.AXIS_NONE, false);

        //reset option to set robot to start Position and pin it into air
        input.addAction(new InputAction() {

            public void performAction(InputActionEvent evt) {
                if (evt.getTriggerPressed()) {

                    roboter.detach();

                    roboter = new Roboter(rootNode,
                            getPhysicsSpace(), floor,
                            roboterPositionController, true,
                            display);

                    roboter.init();


                }
            }
        }, InputHandler.DEVICE_KEYBOARD, KeyInput.KEY_2, InputHandler.AXIS_NONE, false);

        //---------- Set the keyboard shortcuts END ----------//
    }

    @Override
    protected void simpleUpdate() {
        super.simpleUpdate();

        roboter.getRoboPosController().update();

//        getPhysicsSpace().setAccuracy(0.007f);
    }

}
