package mygame;

import com.jme3.app.SimpleApplication;

/**
 * 
 * @author normenhansen
 */
public class Main extends SimpleApplication {

    public static void main(String[] args) {
        Main app = new Main();
        app.start();
    }

    public Main() {
        super(new ConfigAppState());
    }

    @Override
    public void simpleInitApp() {
        rootNode.attachChild(assetManager.loadModel("Scenes/Scene.j3o"));
    }

}
