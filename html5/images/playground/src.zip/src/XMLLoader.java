/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package arm;

import backup.*;
import com.jme.animation.AnimationController;
import com.jme.animation.BoneAnimation;
import com.jme.math.Vector3f;
import com.jme.scene.Controller;
import com.jme.scene.Node;
import com.jme.scene.Spatial;
import com.jme.util.export.xml.XMLImporter;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;


public class XMLLoader {

    public static Node load(File file) {
        Node result = null;
        try {
            XMLImporter xmlFile = new XMLImporter();
            Object o = xmlFile.load(new FileInputStream(file));
            if (!(o instanceof Spatial)) {
                throw new IOException("File contains non-spatial root: " + o.getClass().getName());
            } else {
                Spatial loadedSpatial = (Spatial) o;
                result = (Node) loadedSpatial;
                result.setLocalTranslation(new Vector3f(0f, 0f, 0f));
                System.out.println("LoadBlenderModel: " + file.getPath() + " loaded.");
            }
        } catch (IOException ex) {
            Logger.getLogger(XMLLoader.class.getName()).log(Level.SEVERE, null, ex);
        }
        return result;
    }
//public static void printAnims(Node model) {
//        try {
//            Spatial armature = (Spatial) model.getChild("Cube.001");
//            int controllerCount = armature.getControllerCount();
//            System.out.println("controller count: " + controllerCount);
//            if (controllerCount > 0) {
//                if (armature != null) {
//                    AnimationController ac =
//                            (AnimationController) armature.getController(0);
//                    List anims = ac.getAnimations();
//                    for (Object o : anims) {
//                        System.out.println("anims: " + o.toString());
//                    }
//                    ac.setActiveAnimation(anims.get(0).toString());
//                    ac.setSpeed(1f);
//                    ac.setRepeatType(Controller.RT_WRAP);
//                }
//            }
//        } catch (NullPointerException npe) {
//            System.out.println("armature.getControllerCount() npe: " + npe);
//        }
//    }

    public static void printAnims(Node model) {
        try {
            Spatial armature = (Spatial) model.getChild("ArmatureSuperBone");
            int controllerCount = armature.getControllerCount();
            System.out.println("controller count: " + controllerCount);
            if (controllerCount > 0) {
                if (armature != null) {
                    AnimationController ac =
                            (AnimationController) armature.getController(0);
                    List<BoneAnimation> anims = ac.getAnimations();
                    for (BoneAnimation a : anims) {
                        System.out.println("anims: " + a.toString());
                    }
                    ac.setActiveAnimation(anims.get(0).toString());
                    ac.setSpeed(1f);
                    ac.setRepeatType(Controller.RT_WRAP);
                    ac.setActive(true);
                }
            }
        } catch (NullPointerException npe) {
            System.out.println("armature.getControllerCount() npe: " + npe);
        }
    }
}
