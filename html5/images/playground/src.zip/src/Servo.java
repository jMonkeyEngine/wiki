/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package arm;

import com.jme.input.util.SyntheticButton;
import com.jme.math.FastMath;
import com.jme.math.Vector3f;
import com.jmex.physics.DynamicPhysicsNode;
import com.jmex.physics.Joint;
import com.jmex.physics.JointAxis;
import com.jmex.physics.RotationalJointAxis;
import com.jmex.physics.impl.jbullet.joints.JBulletHingeJoint;
import com.jmex.physics.impl.jbullet.joints.JBulletJoint;
import com.jmex.physics.material.Material;
import java.util.logging.Level;
import java.util.logging.Logger;
import jmetest.input.TestInputHandler;

/**
 *
 * @author night
 */
public class Servo {

    private DynamicPhysicsNode dynNode;
    private JBulletJoint joint;
    private JointAxis jointAxis;
    // currentPos are in given in radian 2*PI/360°
    // goalPos are in given in angle
    private float radianToAngle = (float) (180 / Math.PI);
    private float angleToRadian = FastMath.PI / 180;
    private String name = "";
    private float goalPos = 0.0f;
    private float currentPos = 0.0f;
    private float intensity = 1.f;
    //
    private boolean goalAchieved = false;
    private float tmpGoalPos = 0.f;
    private float tmpGoalAddTo = 0.1f;
    private float velocity = 1f;
    //
//    private float toleranz = 1.0f * (FastMath.PI / 180); //1 radian = FastMath.PI / 180
//    private float toleranz = 0.000001f;
    private float toleranz = 1f;
//    private float toleranz = 360.f;
    private float JOINT_EPS = 0.00001f;
    private float minAngleLimit = -180 + getToleranz() / 2;
    private float maxAngleLimit = 180 - getToleranz() / 2;
    private float currentDiff = getMaxAngleLimit();
    private Vector3f axisDirection = new Vector3f();


    public Servo(DynamicPhysicsNode dynNode, Joint joint) {
        this.dynNode = dynNode;

        Material m = Material.PLASTIC;
//        m.setDensity(0.001f);
        dynNode.setMaterial(m);

        if (joint instanceof JBulletJoint) {
            this.joint = (JBulletJoint) joint;
        } else {
            throw new IllegalArgumentException("works only with the Jbullet implementation");
        }

        name = dynNode.getName();


        joint.setBreakingLinearForce(1000000000);
        joint.setBreakingTorque(1000000000);


        //experiment ! how to set the values????
//        joint.setSpring(70, 10); // values from class Swing from jme-demos-physic-fun
//        joint.setSpring(2000, 200); // from jmephysics.googlecode.com/..1
//        joint.setSpring(2000, 400); // from jmephysics.googlecode.com/..2
//        joint.setSpring(20000, 4000);
//        joint.setSpring(0, 0);
//        joint.setSpring(Float.NaN, Float.NaN);//this should make the joint stiff !!!
        joint.setSpring(0, 1000000000);

        if (!dynNode.getName().equals("Brust")) {
            jointAxis = getJoint().getAxes().get(0);
            jointAxis.getDirection(axisDirection);
            axisDirection.normalize();
//
//            jointAxis.setPositionMinimum(goalPos * angleToRadian);
//            jointAxis.setPositionMaximum((goalPos + JOINT_EPS) * angleToRadian);

            jointAxis.setPositionMaximum((currentPos - JOINT_EPS) * angleToRadian);
            jointAxis.setPositionMinimum((currentPos + JOINT_EPS) * angleToRadian);
        }
    }

    public void update() {

//        dynNode.clearDynamics();

        if (!dynNode.getName().equals("Brust")) {

            if (goalPos < getMinAngleLimit()) {
                goalPos = getMinAngleLimit();
                System.out.println("goal position is smaller than min angle limit for " + name);
                System.out.println("goal position set to limit value!");
            }
            if (goalPos > getMaxAngleLimit()) {
                goalPos = getMaxAngleLimit();
                System.out.println("goal position is bigger than max angle limit for " + name);
                System.out.println("goal position set to limit value!");
            }

            currentPos = jointAxis.getPosition() * radianToAngle;
            currentDiff = FastMath.abs(currentPos - goalPos);
//            currentDiff = FastMath.abs(currentPos - tmpGoalPos);


            if (currentDiff > getToleranz()) {

//                jointAxis.setPositionMaximum(getMaxAngleLimit());
//                jointAxis.setPositionMinimum(getMinAngleLimit());

                jointAxis.setPositionMaximum((currentPos - JOINT_EPS) * angleToRadian);
                jointAxis.setPositionMinimum((currentPos + JOINT_EPS) * angleToRadian);

//                float velocity = (float) (currentDiff / Math.pow(Math.E, Math.min(5.f, intensity * currentDiff)));
//                float velocity = (float) (7 / Math.exp(1 / (currentDiff)));

//                float velocity = (currentDiff - diffValues[0])*(0.0075f);
//                float velocity
//                diffValues[0] = currentDiff;


//                velocity+=0.05f;
                velocity += (float) (0.03 / Math.exp(1 / (currentDiff)));
                velocity = Math.min(velocity, 10);

                System.out.println("velocity: " + velocity);

                if (currentPos > goalPos) {

                    // using enableAngularMotor() for joints you need
                    // the modified jme2Physic.jar file
//                        joint.enableAngularMotor(true, -1.f, 100000);
//                        joint.enableAngularMotor(true, -2.f, 100000);
                    joint.enableAngularMotor(true, -velocity, velocity * 0.1f);

                } else {
//                        joint.enableAngularMotor(true, 1.f, 100000);
//                        joint.enableAngularMotor(true, 2.f, 100000);
                    joint.enableAngularMotor(true, velocity, velocity * 0.1f);
                }

                System.out.println("Toleranz= " + getToleranz());
                System.out.println("currentPos " + getName() + ": " + currentPos);
                System.out.println("goalPos " + getName() + ": " + goalPos);
                System.out.println("");

            }// end if (currentDiff >= getToleranz())
            else {
                joint.enableAngularMotor(false, 0.f, 0.f);
                goalAchieved = true;

                velocity -= velocity * 0.3f;
//                velocity-=(float) (0.01 / Math.exp(1 / (currentDiff)));
                velocity = Math.max(velocity, 1f);

                jointAxis.setPositionMinimum(goalPos * angleToRadian);
                jointAxis.setPositionMaximum((goalPos + JOINT_EPS) * angleToRadian);
            }
//            }// end if (! goalAchieved)

        }// end if (!dynNode.getName().equals("Brust")) 
    }

    /**
     * @return the goalPos
     */
    public float getGoalPos() {
        return goalPos;
    }

    /**
     * @param goalPos the goalPos to set
     */
    public void setGoalPos(float goalPos) {
        this.goalPos = goalPos;
        goalAchieved = false;
    }

//    /**
//     * @return the intensity
//     */
//    public float getIntensityFactor() {
//        return intensityFactor;
//    }
//
//    /**
//     * @param intensity the intensity to set
//     */
//    public void setIntensityFactor(float intensity) {
//        this.intensityFactor = intensity;
//    }
    /**
     * @return the dynNode
     */
    public DynamicPhysicsNode getDynNode() {
        return dynNode;
    }

    /**
     * @return the joint
     */
    public Joint getJoint() {
        return joint;
    }

    /**
     * @return the minAngleLimit
     */
    public float getMinAngleLimit() {
        return minAngleLimit;
    }

    /**
     * @param minAngleLimit the minAngleLimit to set
     */
    public void setMinAngleLimit(float minAngleLimit) {
        this.minAngleLimit = minAngleLimit;
    }

    /**
     * @return the maxAngleLimit
     */
    public float getMaxAngleLimit() {
        return maxAngleLimit;
    }

    /**
     * @param maxAngleLimit the maxAngleLimit to set
     */
    public void setMaxAngleLimit(float maxAngleLimit) {
        this.maxAngleLimit = maxAngleLimit;
    }

    /**
     * @return the toleranz
     */
    public float getToleranz() {
        return toleranz;
    }

    /**
     * @param toleranz the toleranz to set
     */
    public void setToleranz(float toleranz) {
        this.toleranz = toleranz;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @return the goalAchieved
     */
    public boolean isGoalAchieved() {
        return goalAchieved;
    }

    /**
     * @return the intensity
     */
    public float getIntensity() {
        return intensity;
    }

    /**
     * @param intensity the intensity to set
     */
    public void setIntensity(float intensity) {
        this.intensity = intensity;
    }
}
