/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package arm;

import java.util.ArrayList;

/**
 *
 * @author night
 */
public class RoboterPositions extends ArrayList<RoboterPosition>{

}
