
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package arm;

import com.jme.bounding.BoundingBox;
import com.jme.input.InputHandler;
import com.jme.input.KeyInput;
import com.jme.input.action.InputAction;
import com.jme.input.action.InputActionEvent;
import com.jme.math.FastMath;
import com.jme.math.Quaternion;
import com.jme.math.Vector3f;
import com.jme.scene.Node;
import com.jme.scene.Spatial;
import com.jme.scene.shape.Box;
import com.jme.system.GameSettings;
import com.jmex.physics.DynamicPhysicsNode;
import com.jmex.physics.Joint;
import com.jmex.physics.PhysicsSpace;
import com.jmex.physics.RotationalJointAxis;
import com.jmex.physics.StaticPhysicsNode;
//import com.jmex.physics.util.SimplePhysicsGame;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Main extends SimpleRobotGame {
//public class Main extends SimplePhysicsGame {

    private Node fileNode;
    private float scale = 1.0f;
//    private float mass = 10; // orginal value
    private float mass = 0.1f;
    protected float angle = FastMath.PI / 18.f;
    //
    private Vector3f xAchse = new Vector3f(1, 0, 0);
    private Vector3f yAchse = new Vector3f(0, 1, 0);
    private Vector3f zAchse = new Vector3f(0, 0, 1);
//
//    private boolean boxModel = false;
    private boolean boxModel = true;
//
    private RoboterPositionController roboPosController = new RoboterPositionController();
    //

    public static void main(String[] args) {

        Main app = new Main();
//        app.setConfigShowMode(ConfigShowMode.NeverShow);
        app.setConfigShowMode(ConfigShowMode.AlwaysShow);

        PhysicsSpace.chooseImplementation("JBullet");

        app.start(); // Start the program
    }

    protected void simpleInitGame() {

        //*************** Boden BEGIN //***************
        StaticPhysicsNode staticNode = getPhysicsSpace().createStaticNode();
        rootNode.attachChild(staticNode);
//        final Box visualFloorBox = new Box("floor", new Vector3f(0, -30f, 0), 50, 0.25f, 50);
        final Box visualFloorBox = new Box("floor", new Vector3f(0, -0.25f, 0), 15, 0.25f, 15);
        staticNode.attachChild(visualFloorBox);
        staticNode.generatePhysicsGeometry();

        cam.setLocation(new Vector3f(-5, 5, 0));
        cam.lookAt(new Vector3f(3, 0, 0), yAchse);
        //*************** Boden END //***************

        //*************** LOAD BEGIN //***************
        if (boxModel) {
//            fileNode = XMLLoader.load(new File("src/roboter-gestreckt-jme.xml"));
//            fileNode = XMLLoader.load(new File("src/roboterboundingteilemarina-jme.xml"));
//            fileNode = XMLLoader.load(new File("src/roboter-jme.xml"));
            fileNode = XMLLoader.load(new File("src/roboterboxmodell-jme.xml"));
        } else {
            fileNode = XMLLoader.load(new File("src/roboter-jme.xml"));
//            fileNode = XMLLoader.load(new File("src/roboterboundingteilemarina-jme.xml"));
//            fileNode = XMLLoader.load(new File("src/roboterboxmodell-jme.xml"));
        }

        roboPosController.getServoHashMap().put("Brust", addRoboterPart("Brust", null, null));

        roboPosController.getServoHashMap().put("Kopf", addRoboterPart("Kopf", yAchse,
                roboPosController.getServoHashMap().get("Brust").getDynNode()));
        //-------------------------
        roboPosController.getServoHashMap().put("rOberarm", addRoboterPart("rOberarm", xAchse.mult(-1),
                roboPosController.getServoHashMap().get("Brust").getDynNode()));

        roboPosController.getServoHashMap().put("rUnterarm", addRoboterPart("rUnterarm", yAchse.mult(-1),
                roboPosController.getServoHashMap().get("rOberarm").getDynNode()));

        roboPosController.getServoHashMap().put("rHand", addRoboterPart("rHand", xAchse.mult(-1),
                roboPosController.getServoHashMap().get("rUnterarm").getDynNode()));
        //-------------------------
        roboPosController.getServoHashMap().put("lOberarm", addRoboterPart("lOberarm", xAchse,
                roboPosController.getServoHashMap().get("Brust").getDynNode()));

        roboPosController.getServoHashMap().put("lUnterarm", addRoboterPart("lUnterarm", yAchse,
                roboPosController.getServoHashMap().get("lOberarm").getDynNode()));

        roboPosController.getServoHashMap().put("lHand", addRoboterPart("lHand", xAchse,
                roboPosController.getServoHashMap().get("lUnterarm").getDynNode()));
        //-------------------------
        roboPosController.getServoHashMap().put("lHuefte", addRoboterPart("lHuefte", yAchse,
                roboPosController.getServoHashMap().get("Brust").getDynNode()));

        roboPosController.getServoHashMap().put("lOberschenkelServo", addRoboterPart("lOberschenkelServo", xAchse,
                roboPosController.getServoHashMap().get("lHuefte").getDynNode()));

        roboPosController.getServoHashMap().put("lOberschenkel", addRoboterPart("lOberschenkel", zAchse,
                roboPosController.getServoHashMap().get("lOberschenkelServo").getDynNode()));

        roboPosController.getServoHashMap().put("lUnterschenkel", addRoboterPart("lUnterschenkel", zAchse,
                roboPosController.getServoHashMap().get("lOberschenkel").getDynNode()));

        roboPosController.getServoHashMap().put("lFussServo", addRoboterPart("lFussServo", zAchse,
                roboPosController.getServoHashMap().get("lUnterschenkel").getDynNode()));

        roboPosController.getServoHashMap().put("lFuss", addRoboterPart("lFuss", xAchse,
                roboPosController.getServoHashMap().get("lFussServo").getDynNode()));
        //-------------------------
        roboPosController.getServoHashMap().put("rHuefte", addRoboterPart("rHuefte", yAchse,
                roboPosController.getServoHashMap().get("Brust").getDynNode()));

        roboPosController.getServoHashMap().put("rOberschenkelServo", addRoboterPart("rOberschenkelServo", xAchse.mult(-1),
                roboPosController.getServoHashMap().get("rHuefte").getDynNode()));

        roboPosController.getServoHashMap().put("rOberschenkel", addRoboterPart("rOberschenkel", zAchse,
                roboPosController.getServoHashMap().get("rOberschenkelServo").getDynNode()));

        roboPosController.getServoHashMap().put("rUnterschenkel", addRoboterPart("rUnterschenkel", zAchse,
                roboPosController.getServoHashMap().get("rOberschenkel").getDynNode()));

        roboPosController.getServoHashMap().put("rFussServo", addRoboterPart("rFussServo", zAchse,
                roboPosController.getServoHashMap().get("rUnterschenkel").getDynNode()));

        roboPosController.getServoHashMap().put("rFuss", addRoboterPart("rFuss", xAchse.mult(-1),
                roboPosController.getServoHashMap().get("rFussServo").getDynNode()));
        //-------------------


//        input.addAction(new PositiveRotation(kopfServo.getJoint()), InputHandler.DEVICE_KEYBOARD, KeyInput.KEY_0, InputHandler.AXIS_NONE, false);
//        input.addAction(new NegativeRotation(kopfServo.getJoint()), InputHandler.DEVICE_KEYBOARD, KeyInput.KEY_9, InputHandler.AXIS_NONE, false);

              roboPosController.init();

//        RoboterPosition pos1 = new RoboterPosition();
//        pos1.setLOberarmPos(47f);
//        pos1.setROberarmPos(45f);
////        pos1.setKopfPos(45.f);
//        roboPosController.addRoboterPosition(pos1);
//
//        RoboterPosition pos2 = new RoboterPosition();
//        pos2.setLOberarmPos(10f);
//        pos2.setROberarmPos(60f);
//        pos2.setLHueftePos(-45f);
//        pos2.setRHueftePos(45f);
////        pos2.setKopfPos(-25.f);
//        roboPosController.addRoboterPosition(pos2);
//
//        RoboterPosition pos3 = new RoboterPosition();
//        pos3.setLUnterarmPos(50f);
//        pos3.setRUnterarmPos(50f);
//        pos3.setLOberschenkelPos(-50f);
//        pos3.setROberschenkelPos(-50f);
////        pos3.setKopfPos(0.f);
//        roboPosController.addRoboterPosition(pos3);
//
//        RoboterPosition pos4 = new RoboterPosition();
//        pos4.setKopfPos(20.f);
//        pos4.setLUnterschenkelPos(-77.f);
//        pos4.setLFussPos(20.f);
//        pos4.setRUnterschenkelPos(-77.f);
//        pos4.setRFussPos(20.f);
//        roboPosController.addRoboterPosition(pos4);
//
//        RoboterPosition pos5 = new RoboterPosition();
//        pos5.setKopfPos(20.f);
//        pos5.setLOberarmPos(120.f);
//        pos5.setROberarmPos(120.f);
//        pos5.setLUnterschenkelPos(75.f);
//        pos5.setRUnterschenkelPos(-75.f);
//        pos5.setLFussPos(20.f);
//        pos5.setRFussPos(-20.f);
//        roboPosController.addRoboterPosition(pos5);
//
//        try {
//            roboPosController.savePositions(new File("positionen01.xml"));
//        } catch (FileNotFoundException ex) {
//            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
//        }

        try {
            roboPosController.loadPositions(new File("positionen01.xml"));
            System.out.println("SIZE: " + roboPosController.positions.size());

        } catch (FileNotFoundException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        }

        roboPosController.resetPositionPointer();
        roboPosController.currentPosition();

//        System.out.println("Pos: " + roboPosController.positions.get(0).getROberarmPos());

         input.addAction(new InputAction() {

            public void performAction(InputActionEvent evt) {
                roboPosController.nextGoalPosition();
            }
        }, InputHandler.DEVICE_KEYBOARD, KeyInput.KEY_ADD, InputHandler.AXIS_NONE, false);

        input.addAction(new InputAction() {

            public void performAction(InputActionEvent evt) {
                roboPosController.previousGoalPosition();
            }
        }, InputHandler.DEVICE_KEYBOARD, KeyInput.KEY_MULTIPLY, InputHandler.AXIS_NONE, false);

    }

    @Override
    protected void simpleUpdate() {
        super.simpleUpdate();

        roboPosController.update();

    }

    public Servo addRoboterPart(
            String name,
            Vector3f direction,
            DynamicPhysicsNode addToNode) {

        Spatial spatial = fileNode.getChild(name);
        spatial.setLocalScale(scale / 10);

        Vector3f spatialPos = spatial.getLocalTranslation();
        spatial.setLocalTranslation(new Vector3f(0, 0, 0));

        DynamicPhysicsNode dynPhysNode = getPhysicsSpace().createDynamicNode();
        dynPhysNode.attachChild(spatial);
        dynPhysNode.setLocalScale(scale);

        System.out.println("boxModel: " + boxModel);
        System.out.println("RoboPart: " + name);
        if (boxModel) {

            spatial.setModelBound(new BoundingBox());
            spatial.updateModelBound();

            dynPhysNode.generatePhysicsGeometry(false);
//            dynPhysNode.generatePhysicsGeometry();

        } else {
            dynPhysNode.generatePhysicsGeometry(true);
        }

        dynPhysNode.setName(name);
        dynPhysNode.setMass(mass);

        rootNode.attachChild(dynPhysNode);

//        Spatial hilfsSpatial = fileNode.getChild("h" + name);
//        Vector3f dynPhysNodePos = new Vector3f(hilfsSpatial.getLocalTranslation());
//        dynPhysNode.getLocalTranslation().set(dynPhysNodePos);

        dynPhysNode.getLocalTranslation().set(spatialPos);

        Joint joint = getPhysicsSpace().createJoint();
        joint.setActive(true);
        joint.setCollisionEnabled(false);

        Spatial anchorSpatial = fileNode.getChild("h" + name);
        Vector3f anchorPos = new Vector3f(anchorSpatial.getLocalTranslation());

        // if anchor with two nodes then use anchorPos relative to node#1
        if (addToNode != null) {
            anchorPos = anchorSpatial.getLocalTranslation().subtract(addToNode.getLocalTranslation());
        }

        joint.setAnchor(anchorPos);
//            joint.setAnchor(spatialPos);

        dynPhysNode.setCenterOfMass(dynPhysNode.getWorldTranslation());

        if (direction != null) {
            RotationalJointAxis rotationAxis = joint.createRotationalAxis();
            rotationAxis.setDirection(direction);
        }

        // if anchor with two nodes then use anchorPos relative to node#1
        if (addToNode != null) {
            joint.attach(addToNode, dynPhysNode);
            joint.setActive(true);
            // disable collision detection between joint bodies
//            joint.setCollisionEnabled(false);

        } else {
            /*if the following line isn´t commented out (means codeline is used)
            the thorax will be pinned into the air,
            that means the whole body will not fall on the ground*/
//            joint.attach(dynPhysNode);
        }
        return new Servo(dynPhysNode, joint);
    }

    private class NegativeRotation extends InputAction {

        private Joint joint;

        public NegativeRotation(Joint joint) {
            this.joint = joint;
        }

        @Override
        public void performAction(InputActionEvent evt) {

            float min = joint.getAxes().get(0).getPositionMinimum();
            float max = joint.getAxes().get(0).getPositionMaximum();

            if (((min - angle) <= (-FastMath.PI + angle / 2)) || ((max - angle) <= (-FastMath.PI + angle / 2))) {

                System.out.println("MIN Rotation achieved");

            } else {
                min -= angle;
                max -= angle;

                joint.getAxes().get(0).setPositionMinimum(min);
                joint.getAxes().get(0).setPositionMaximum(max);
            }
        }
    }

    private class PositiveRotation extends InputAction {

        private Joint joint;

        public PositiveRotation(Joint joint) {
            this.joint = joint;
        }

        @Override
        public void performAction(InputActionEvent evt) {

            float min = joint.getAxes().get(0).getPositionMinimum();
            float max = joint.getAxes().get(0).getPositionMaximum();

            if (((min + angle) >= (FastMath.PI - angle / 2)) || ((max + angle) >= (FastMath.PI - angle / 2))) {

                System.out.println("MAX Rotation achieved");

            } else {
                min += angle;
                max += angle;

                joint.getAxes().get(0).setPositionMinimum(min);
                joint.getAxes().get(0).setPositionMaximum(max);
            }
        }
    }

//-------------------------
    public void addNewBox(Vector3f vector) {
        addNewBox(vector, null, true, 10);
    }

    public void addNewBox(Vector3f vector, float mass) {
        addNewBox(vector, null, true, mass);
    }

    public void addNewBox(Vector3f vector, Quaternion rotation, boolean gravity, float mass) {

        DynamicPhysicsNode dynamicNode = getPhysicsSpace().createDynamicNode();
        rootNode.attachChild(dynamicNode);

        final Box visualFallingBox = new Box("falling box", new Vector3f(), 0.3f, 0.3f, 0.3f);

        dynamicNode.attachChild(visualFallingBox);
        dynamicNode.generatePhysicsGeometry();
        dynamicNode.getLocalTranslation().set(vector);

        if (rotation != null) {
            dynamicNode.getLocalRotation().set(rotation);
        }

        dynamicNode.setAffectedByGravity(gravity);
        dynamicNode.setMass(mass);
    }
}
