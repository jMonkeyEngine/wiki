/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package arm;

/**
 *
 * @author night
 */
public class RoboterPosition {

    private Float kopfPos;
    //
    private Float rOberarmPos;
    private Float rUnterarmPos;
    private Float rHandPos;
    //
    private Float lOberarmPos;
    private Float lUnterarmPos;
    private Float lHandPos;
    //
    private Float lHueftePos;
    private Float lOberschenkelServoPos;
    private Float lOberschenkelPos;
    private Float lUnterschenkelPos;
    private Float lFussServoPos;
    private Float lFussPos;
    //
    private Float rHueftePos;
    private Float rOberschenkelServoPos;
    private Float rOberschenkelPos;
    private Float rUnterschenkelPos;
    private Float rFussServoPos;
    private Float rFussPos;

    public RoboterPosition() {
        kopfPos = 0.f;
        //
        rOberarmPos = 0.f;
        rUnterarmPos = 0.f;
        rHandPos = 0.f;
        //
        lOberarmPos = 0.f;
        lUnterarmPos = 0.f;
        lHandPos = 0.f;
        //
        lHueftePos = 0.f;
        lOberschenkelServoPos = 0.f;
        lOberschenkelPos = 0.f;
        lUnterschenkelPos = 0.f;
        lFussServoPos = 0.f;
        lFussPos = 0.f;
        //
        rHueftePos = 0.f;
        rOberschenkelServoPos = 0.f;
        rOberschenkelPos = 0.f;
        rUnterschenkelPos = 0.f;
        rFussServoPos = 0.f;
        rFussPos = 0.f;
    }

    /**
     * @return the kopfPos
     */
    public Float getKopfPos() {
        return kopfPos;
    }

    /**
     * @param kopfPos the kopfPos to set
     */
    public void setKopfPos(Float kopfPos) {
        this.kopfPos = kopfPos;
    }

    /**
     * @return the rOberarmPos
     */
    public Float getROberarmPos() {
        return rOberarmPos;
    }

    /**
     * @param rOberarmPos the rOberarmPos to set
     */
    public void setROberarmPos(Float rOberarmPos) {
        this.rOberarmPos = rOberarmPos;
    }

    /**
     * @return the rUnterarmPos
     */
    public Float getRUnterarmPos() {
        return rUnterarmPos;
    }

    /**
     * @param rUnterarmPos the rUnterarmPos to set
     */
    public void setRUnterarmPos(Float rUnterarmPos) {
        this.rUnterarmPos = rUnterarmPos;
    }

    /**
     * @return the rHandPos
     */
    public Float getRHandPos() {
        return rHandPos;
    }

    /**
     * @param rHandPos the rHandPos to set
     */
    public void setRHandPos(Float rHandPos) {
        this.rHandPos = rHandPos;
    }

    /**
     * @return the lOberarmPos
     */
    public Float getLOberarmPos() {
        return lOberarmPos;
    }

    /**
     * @param lOberarmPos the lOberarmPos to set
     */
    public void setLOberarmPos(Float lOberarmPos) {
        this.lOberarmPos = lOberarmPos;
    }

    /**
     * @return the lUnterarmPos
     */
    public Float getLUnterarmPos() {
        return lUnterarmPos;
    }

    /**
     * @param lUnterarmPos the lUnterarmPos to set
     */
    public void setLUnterarmPos(Float lUnterarmPos) {
        this.lUnterarmPos = lUnterarmPos;
    }

    /**
     * @return the lHandPos
     */
    public Float getLHandPos() {
        return lHandPos;
    }

    /**
     * @param lHandPos the lHandPos to set
     */
    public void setLHandPos(Float lHandPos) {
        this.lHandPos = lHandPos;
    }

    /**
     * @return the lHueftePos
     */
    public Float getLHueftePos() {
        return lHueftePos;
    }

    /**
     * @param lHueftePos the lHueftePos to set
     */
    public void setLHueftePos(Float lHueftePos) {
        this.lHueftePos = lHueftePos;
    }

    /**
     * @return the lOberschenkelServoPos
     */
    public Float getLOberschenkelServoPos() {
        return lOberschenkelServoPos;
    }

    /**
     * @param lOberschenkelServoPos the lOberschenkelServoPos to set
     */
    public void setLOberschenkelServoPos(Float lOberschenkelServoPos) {
        this.lOberschenkelServoPos = lOberschenkelServoPos;
    }

    /**
     * @return the lOberschenkelPos
     */
    public Float getLOberschenkelPos() {
        return lOberschenkelPos;
    }

    /**
     * @param lOberschenkelPos the lOberschenkelPos to set
     */
    public void setLOberschenkelPos(Float lOberschenkelPos) {
        this.lOberschenkelPos = lOberschenkelPos;
    }

    /**
     * @return the lUnterschenkelPos
     */
    public Float getLUnterschenkelPos() {
        return lUnterschenkelPos;
    }

    /**
     * @param lUnterschenkelPos the lUnterschenkelPos to set
     */
    public void setLUnterschenkelPos(Float lUnterschenkelPos) {
        this.lUnterschenkelPos = lUnterschenkelPos;
    }

    /**
     * @return the lFussServoPos
     */
    public Float getLFussServoPos() {
        return lFussServoPos;
    }

    /**
     * @param lFussServoPos the lFussServoPos to set
     */
    public void setLFussServoPos(Float lFussServoPos) {
        this.lFussServoPos = lFussServoPos;
    }

    /**
     * @return the lFussPos
     */
    public Float getLFussPos() {
        return lFussPos;
    }

    /**
     * @param lFussPos the lFussPos to set
     */
    public void setLFussPos(Float lFussPos) {
        this.lFussPos = lFussPos;
    }

    /**
     * @return the rHueftePos
     */
    public Float getRHueftePos() {
        return rHueftePos;
    }

    /**
     * @param rHueftePos the rHueftePos to set
     */
    public void setRHueftePos(Float rHueftePos) {
        this.rHueftePos = rHueftePos;
    }

    /**
     * @return the rOberschenkelServoPos
     */
    public Float getROberschenkelServoPos() {
        return rOberschenkelServoPos;
    }

    /**
     * @param rOberschenkelServoPos the rOberschenkelServoPos to set
     */
    public void setROberschenkelServoPos(Float rOberschenkelServoPos) {
        this.rOberschenkelServoPos = rOberschenkelServoPos;
    }

    /**
     * @return the rOberschenkelPos
     */
    public Float getROberschenkelPos() {
        return rOberschenkelPos;
    }

    /**
     * @param rOberschenkelPos the rOberschenkelPos to set
     */
    public void setROberschenkelPos(Float rOberschenkelPos) {
        this.rOberschenkelPos = rOberschenkelPos;
    }

    /**
     * @return the rUnterschenkelPos
     */
    public Float getRUnterschenkelPos() {
        return rUnterschenkelPos;
    }

    /**
     * @param rUnterschenkelPos the rUnterschenkelPos to set
     */
    public void setRUnterschenkelPos(Float rUnterschenkelPos) {
        this.rUnterschenkelPos = rUnterschenkelPos;
    }

    /**
     * @return the rFussServoPos
     */
    public Float getRFussServoPos() {
        return rFussServoPos;
    }

    /**
     * @param rFussServoPos the rFussServoPos to set
     */
    public void setRFussServoPos(Float rFussServoPos) {
        this.rFussServoPos = rFussServoPos;
    }

    /**
     * @return the rFussPos
     */
    public Float getRFussPos() {
        return rFussPos;
    }

    /**
     * @param rFussPos the rFussPos to set
     */
    public void setRFussPos(Float rFussPos) {
        this.rFussPos = rFussPos;
    }



   
}
